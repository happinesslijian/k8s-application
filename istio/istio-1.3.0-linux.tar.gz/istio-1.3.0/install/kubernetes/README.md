# Install Istio on an existing Kubernetes cluster

Please follow the installation instructions on [istio.io](https://istio.io/docs/setup/kubernetes/).

If you want to install Istio using the istio/istio repository instead of downloading a release,
refer to the [developer wiki](https://github.com/istio/istio/wiki) for instructions.
